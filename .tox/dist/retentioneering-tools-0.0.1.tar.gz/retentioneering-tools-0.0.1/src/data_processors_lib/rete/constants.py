from __future__ import annotations

UOM_DICT = {
    's': 1,
    'm': 60,
    'h': 3600,
    'd': 24 * 3600
}
